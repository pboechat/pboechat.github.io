import base64
import os
import tempfile
import matplotlib.pyplot as plt
import sys
from itertools import zip_longest


def flatten(list_):
    return [item for sublist in list_ for item in sublist]


def grouper(n, iterable, fillvalue=None):
    args = [iter(iterable)] * n
    return zip_longest(fillvalue=fillvalue, *args)


def dump_plt_to_svg(close_plot=True):
    with tempfile.NamedTemporaryFile() as tmp_file:
        filepath = tmp_file.name
    plt.savefig(filepath, format='svg', bbox_inches="tight")
    if close_plot:
        plt.close()
    with open(filepath, 'rt') as svg_file:
        svg = svg_file.read()
    os.remove(filepath)
    return svg


def dump_plt_to_disk(filepath, format, close_plot=True):
    plt.savefig(filepath, format=format, bbox_inches="tight")
    if close_plot:
        plt.close()


def image_to_html(image_data, mimetype, width):
    return f'<img src="data:{mimetype};base64,{base64.b64encode(image_data).decode("utf-8")}" width="{width}px" />'


def clear_atexit_excepthook():
    def _clear_atexit_excepthook(exctype, value, traceback):
        # atexit._exithandlers[:] = []
        sys.__excepthook__(exctype, value, traceback)

    sys.excepthook = _clear_atexit_excepthook


def bar_labels(ax, labels, **kwargs):
    y_offset = kwargs.get('y_offset', 0)
    text_kwargs = dict()
    fontsize = kwargs.get('fontsize', None)
    if fontsize is None:
        text_kwargs['fontsize'] = fontsize
    for rect, label in zip(ax.patches, labels):
        height = rect.get_height()
        ax.text(rect.get_x() + rect.get_width() / 2, height + y_offset, label, ha="center", va="bottom", **text_kwargs)
