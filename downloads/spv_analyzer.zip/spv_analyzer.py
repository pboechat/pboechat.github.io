import glob
import hashlib
import os
import subprocess
import sys
from argparse import ArgumentParser
from collections import Counter, defaultdict
import enum
from functools import reduce
from itertools import zip_longest
import numpy as np
import atexit
import jsonpickle

import matplotlib.pyplot as plt

from rdoc import get_texture_type_str, get_var_type_str, create_remote_server_connection, open_remote_capture, \
    traverse_actions, sample_counter, ActionFlags, ShaderEncoding, InitialiseReplay, \
    GlobalEnvironment, ShutdownReplay, GPUCounter, CounterUnit

from reporting_commons import clear_atexit_excepthook

_SPIRV_CROSS_EXEC = r'${VULKAN_SDK}\Bin\spirv-cross.exe'

_SPIRV_DIS_EXEC = r'${VULKAN_SDK}\Bin\spirv-dis.exe'

VERT_SHADER = 0
FRAG_SHADER = 1
COMP_SHADER = 2

_SHADER_MODULE_TYPES = [
    VERT_SHADER,
    FRAG_SHADER,
    COMP_SHADER
]

_SHADER_MODULE_TYPE_NAME = {
    VERT_SHADER: 'Vertex',
    FRAG_SHADER: 'Fragment',
    COMP_SHADER: 'Compute',
}


def get_sig_param_type(sig_param):
    return f'{get_var_type_str(sig_param.varType)}{sig_param.compCount}'


_DECLARATION_INSTR_WEIGHT = 0
_MEMORY_INSTR_WEIGHT = 0.6
_IMAGE_INSTR_WEIGHT = 0.7
_CONVERSION_INSTR_WEIGHT = 0.5
_ARITHMETIC_INSTR_WEIGHT = 0.4
_BIT_AND_LOGIC_INSTR_WEIGHT = 0.3
_DERIVATIVE_INSTR_WEIGHT = 0.7
_CONTROL_FLOW_INSTR_WEIGHT = 0.8
_ATOMIC_INSTR_WEIGHT = 0.8
_BARRIER_INSTR_WEIGHT = 0.9
_GROUP_INSTR_WEIGHT = 0.9
_OTHER_INSTR_WEIGHT = 0

_INSTR_NAMES = ['Memory',
                'Image',
                'Conversion',
                'Arithmetic',
                'Bit & Logic',
                'Derivative',
                'Control-flow',
                'Atomic',
                'Barrier',
                'Group',
                'Other']


class ShaderModuleInstructionStats:
    def __init__(self):
        self.memory_instructions = 0
        self.image_instructions = 0
        self.conversion_instructions = 0
        self.arithmetic_instructions = 0
        self.bit_and_logic_instructions = 0
        self.derivative_instructions = 0
        self.control_flow_instructions = 0
        self.atomic_instructions = 0
        self.barrier_instructions = 0
        self.group_instructions = 0
        self.other_instructions = 0
        self.relaxed_precision_pct = 0

    @property
    def empty(self):
        return self.total == 0

    @property
    def total(self):
        return self.memory_instructions + \
               self.image_instructions + \
               self.conversion_instructions + \
               self.arithmetic_instructions + \
               self.bit_and_logic_instructions + \
               self.derivative_instructions + \
               self.control_flow_instructions + \
               self.atomic_instructions + \
               self.barrier_instructions + \
               self.group_instructions + \
               self.other_instructions + \
               self.relaxed_precision_pct

    @property
    def weighed_memory_instructions(self):
        return self.memory_instructions * _MEMORY_INSTR_WEIGHT

    @property
    def weighed_image_instructions(self):
        return self.image_instructions * _IMAGE_INSTR_WEIGHT

    @property
    def weighed_conversion_instructions(self):
        return self.conversion_instructions * _CONVERSION_INSTR_WEIGHT

    @property
    def weighed_arithmetic_instructions(self):
        return self.arithmetic_instructions * _ARITHMETIC_INSTR_WEIGHT

    @property
    def weighed_bit_and_logic_instructions(self):
        return self.bit_and_logic_instructions * _BIT_AND_LOGIC_INSTR_WEIGHT

    @property
    def weighed_derivative_instructions(self):
        return self.derivative_instructions * _DERIVATIVE_INSTR_WEIGHT

    @property
    def weighed_control_flow_instructions(self):
        return self.control_flow_instructions * _CONTROL_FLOW_INSTR_WEIGHT

    @property
    def weighed_atomic_instructions(self):
        return self.atomic_instructions * _ATOMIC_INSTR_WEIGHT

    @property
    def weighed_barrier_instructions(self):
        return self.barrier_instructions * _BARRIER_INSTR_WEIGHT

    @property
    def weighed_group_instructions(self):
        return self.group_instructions * _GROUP_INSTR_WEIGHT

    @property
    def weighed_other_instructions(self):
        return self.other_instructions * _OTHER_INSTR_WEIGHT

    @property
    def complexity(self):
        return self.weighed_memory_instructions + \
               self.weighed_image_instructions + \
               self.weighed_conversion_instructions + \
               self.weighed_arithmetic_instructions + \
               self.weighed_bit_and_logic_instructions + \
               self.weighed_derivative_instructions + \
               self.weighed_control_flow_instructions + \
               self.weighed_atomic_instructions + \
               self.weighed_barrier_instructions + \
               self.weighed_group_instructions + \
               self.weighed_other_instructions


class ShaderModuleResource:
    def __init__(self, name, bind, type, readonly):
        self.name = name
        self.bind = bind
        self.type = type
        self.readonly = readonly


class ShaderModuleInput:
    def __init__(self, name, type, semantic):
        self.name = name
        self.type = type
        self.semantic = semantic


class Shader:
    def __init__(self,
                 hash,
                 module_inputs,
                 module_resources,
                 module_sources,
                 module_instruction_stats):
        self.hash = hash
        self.module_inputs = module_inputs
        self.module_resources = module_resources
        self.module_sources = module_sources
        self.module_instruction_stats = module_instruction_stats

    def __repr__(self):
        return 'Shader(' \
               f'hash={self.hash}' \
               f', resources={self.module_resources}' \
               f', sources={self.module_sources}' \
               f', instruction_stats={self.module_instruction_stats}' \
               ')'


def _get_spv_hash(spv):
    return hashlib.md5(spv).hexdigest()


_SPIRV_ASM_CACHE = dict()


def convert_to_spvasm(spv, spirv_dis_exec):
    global _SPIRV_ASM_CACHE

    spv_hash = _get_spv_hash(spv)

    spirv_asm = _SPIRV_ASM_CACHE.get(spv_hash, None)
    if spirv_asm is None:
        proc = subprocess.Popen(f'{os.path.expandvars(spirv_dis_exec)} -o - --comment -', stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
        spirv_asm_bytes, err = proc.communicate(input=spv)

        if proc.returncode != 0:
            return None

        spirv_asm = spirv_asm_bytes.decode('utf-8')
        _SPIRV_ASM_CACHE[spv_hash] = spirv_asm

    return spirv_asm


_HLSL_CACHE = dict()


def convert_to_hlsl(spv, spirv_cross_exec):
    global _HLSL_CACHE

    spv_hash = _get_spv_hash(spv)

    hlsl = _HLSL_CACHE.get(spv_hash, None)
    if hlsl is None:
        proc = subprocess.Popen(f'{os.path.expandvars(spirv_cross_exec)} --hlsl --shader-model 61 -',
                                stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
        hlsl_bytes, err = proc.communicate(input=spv)

        if proc.returncode != 0:
            return None

        hlsl = hlsl_bytes.decode('utf-8')
        _HLSL_CACHE[spv_hash] = hlsl

    return hlsl


_OPCODE_DECORATE = 71
_OPCODE_DECORATE_MEMBER = 72
_OPCODES_MEMORY = list(range(59, 71)) + list(range(401, 404))
_OPCODES_IMAGE = list(range(86, 108)) + list(range(305, 321)) + [5283]
_OPCODES_CONVERSION = list(range(109, 125))
_OPCODES_ARITHMETIC = list(range(126, 153)) + list(range(4450, 4456))
_OPCODES_BIT_AND_LOGIC = list(range(194, 206)) + list(range(154, 192))
_OPCODES_DERIVATIVE = list(range(207, 216))
_OPCODES_CONTROL_FLOW = list(range(245, 254)) + list(range(255, 258)) + [4416, 5380]
_OPCODES_ATOMIC = list(range(227, 243)) + list(range(318, 320)) + list(range(5614, 5616)) + [6035]
_OPCODES_BARRIER = list(range(224, 226)) + list(range(328, 330)) + list(range(6142, 6144))
_OPCODES_GROUP = list(range(259, 272)) + list(range(4421, 4433)) + list(range(5000, 5008)) + list(range(5571, 5582)) + \
                 list(range(6401, 6409))


def parse_shader_instruction_stats(spirv):
    i = 0

    def read_int(s):
        nonlocal i
        data = int.from_bytes(spirv[i:i + s], byteorder='little', signed=False)
        i += s
        return data

    def skip(s):
        nonlocal i
        i += s

    magic = read_int(4)
    if magic != 0x07230203:
        raise Exception('Invalid SPIR-V magic number!')

    skip(4)  # version
    skip(4)  # generators magic number
    skip(4)  # bound
    skip(4)  # reserved

    stats = ShaderModuleInstructionStats()
    decorate_count = 0
    relaxed_precision_count = 0
    while i < len(spirv):
        opcode = read_int(2)
        word_count = read_int(2)

        if opcode == _OPCODE_DECORATE or opcode == _OPCODE_DECORATE_MEMBER:
            assert word_count >= 1
            skip(4)  # target
            if opcode == _OPCODE_DECORATE_MEMBER:
                assert word_count >= 3
                word_count -= 3
                skip(4)  # member
            else:
                assert word_count >= 2
                word_count -= 2
            decoration = read_int(4)
            decorate_count += 1
            if decoration == 0:
                relaxed_precision_count += 1

        if opcode in _OPCODES_MEMORY:
            stats.memory_instructions += 1
        elif opcode in _OPCODES_IMAGE:
            stats.image_instructions += 1
        elif opcode in _OPCODES_CONVERSION:
            stats.conversion_instructions += 1
        elif opcode in _OPCODES_ARITHMETIC:
            stats.arithmetic_instructions += 1
        elif opcode in _OPCODES_BIT_AND_LOGIC:
            stats.bit_and_logic_instructions += 1
        elif opcode in _OPCODES_DERIVATIVE:
            stats.derivative_instructions += 1
        elif opcode in _OPCODES_CONTROL_FLOW:
            stats.control_flow_instructions += 1
        elif opcode in _OPCODES_ATOMIC:
            stats.atomic_instructions += 1
        elif opcode in _OPCODES_BARRIER:
            stats.barrier_instructions += 1
        elif opcode in _OPCODES_GROUP:
            stats.group_instructions += 1
        else:
            stats.other_instructions += 1

        skip((word_count - 1) * 4)

    if decorate_count > 0:
        stats.relaxed_precision_pct = relaxed_precision_count / decorate_count

    return stats


def parse_shaders(replay_controller, spirv_cross_exec, spirv_dis_exec, shaders):
    print('Parsing shaders')

    log_count = 0

    class LogSeverity(enum.IntEnum):
        NORMAL = enum.auto()
        ERROR = enum.auto()

    def log(msg, severity=LogSeverity.NORMAL):
        nonlocal log_count
        file = sys.stderr if severity == LogSeverity.ERROR else sys.stdout
        print(msg, file=file, end='', flush=True)
        log_count += 1
        if log_count % 100 == 0:
            print('')

    def shaders_visitor(action, *_):
        is_draw = action.flags & ActionFlags.Drawcall != 0
        is_dispatch = action.flags & ActionFlags.Dispatch != 0

        # ignore non-draw/dispatch commands
        if not is_draw and not is_dispatch:
            return

        num_indices = action.numIndices
        if action.flags & ActionFlags.Instanced != 0:
            num_indices *= action.numInstances

        replay_controller.SetFrameEvent(action.eventId, True)

        vk_pipe_state = replay_controller.GetVulkanPipelineState()

        def disassemble_shader(_vk_shader, _vk_pipeline):
            assert _vk_shader.reflection.encoding == ShaderEncoding.SPIRV, \
                f'Shader encoding not SPIRV (encoding={_vk_shader.reflection.encoding})'
            spv = _vk_shader.reflection.rawBytes
            low_level_source = convert_to_spvasm(spv, spirv_dis_exec)
            high_level_source = convert_to_hlsl(spv, spirv_cross_exec)
            if high_level_source is None:
                log(f'\nFailed to convert SPIR-V into HLSL\n', LogSeverity.ERROR)
                high_level_source = replay_controller.DisassembleShader(_vk_pipeline.pipelineResourceId,
                                                                        _vk_shader.reflection,
                                                                        '')
            return (low_level_source, high_level_source), hashlib.md5(spv).hexdigest()

        vk_shader_modules = [None] * len(_SHADER_MODULE_TYPES)
        sources = [None] * len(_SHADER_MODULE_TYPES)
        hashes = [None] * len(_SHADER_MODULE_TYPES)
        vk_pipeline = None
        if is_draw:
            vk_shader_modules[VERT_SHADER] = vk_pipe_state.vertexShader
            vk_shader_modules[FRAG_SHADER] = vk_pipe_state.fragmentShader
            vk_pipeline = vk_pipe_state.graphics
        else:  # is_dispatch
            assert is_dispatch  # checking invariants
            vk_shader_modules[COMP_SHADER] = vk_pipe_state.computeShader
            vk_pipeline = vk_pipe_state.compute

        hash = 0
        for module_type, vk_shader_module in enumerate(vk_shader_modules):
            if vk_shader_module is None:
                continue
            module_source, module_hash = disassemble_shader(vk_shader_module, vk_pipeline)
            sources[module_type] = module_source
            hash += module_hash

        if hash in hashes:
            log('.')
            return

        inputs = [list()] * len(_SHADER_MODULE_TYPES)
        resources = [list()] * len(_SHADER_MODULE_TYPES)
        instruction_stats = [ShaderModuleInstructionStats()] * len(_SHADER_MODULE_TYPES)
        bind = 0
        for module_type, vk_shader_module in enumerate(vk_shader_modules):
            if vk_shader_module is None:
                continue

            instruction_stats[module_type] = parse_shader_instruction_stats(vk_shader_module.reflection.rawBytes)

            module_inputs = []
            for sig_param in vk_shader_module.reflection.inputSignature:
                module_inputs.append(ShaderModuleInput(sig_param.varName,
                                                       get_sig_param_type(sig_param),
                                                       sig_param.semanticIdxName))

            inputs[module_type] = module_inputs

            refl_resources = list(vk_shader_module.reflection.readOnlyResources) + \
                             list(vk_shader_module.reflection.readWriteResources)
            module_resources = []
            for refl_resource in refl_resources:
                module_resources.append(ShaderModuleResource(refl_resource.name,
                                                             bind,
                                                             get_texture_type_str(refl_resource.resType),
                                                             refl_resource.isReadOnly))
                bind += 1
            resources[module_type] = module_resources

        shader = Shader(hash,
                        inputs,
                        resources,
                        sources,
                        instruction_stats)
        shaders[hash] = shader
        log('o')

    traverse_actions(replay_controller, shaders_visitor)
    print('', flush=True)


def main():
    parser = ArgumentParser()
    parser.add_argument('-i', '--input', type=str, required=True)
    parser.add_argument('-o', '--output', type=str, required=False)
    parser.add_argument('--spirv_cross', type=str, required=False, default=_SPIRV_CROSS_EXEC)
    parser.add_argument('--spirv_dis', type=str, required=False, default=_SPIRV_DIS_EXEC)
    args = parser.parse_args()

    if '*' in args.input:
        capture_paths = glob.glob(args.input)
    elif os.path.isdir(args.input):
        capture_paths = [os.path.join(args.input, file)
                         for file in os.listdir(args.input)
                         if os.path.splitext(file)[1] == '.rdc']
    else:
        capture_paths = [args.input]

    if len(capture_paths) == 0:
        print("Input doesn't exist")
        sys.exit(-1)

    if args.output is None:
        report_path = os.path.splitext(capture_paths[0])[0] + '_report.html'
    elif os.path.isdir(args.output):
        report_path = os.path.join(args.output, '_report.html')
    else:
        report_path = args.output

    os.makedirs(os.path.split(report_path)[0], exist_ok=True)

    shaders = dict()

    InitialiseReplay(GlobalEnvironment(), [])

    replay_controler = None
    remote_server = create_remote_server_connection()

    def shutdown_replay():
        if replay_controler is not None:
            remote_server.CloseCapture(replay_controller)

        remote_server.ShutdownConnection()

        ShutdownReplay()

    clear_atexit_excepthook()
    atexit.register(shutdown_replay)

    for capture_idx, capture_path in enumerate(capture_paths):
        print(f'[{capture_idx + 1}/{len(capture_paths)}] Capture path: {capture_path}')

        replay_controller = open_remote_capture(remote_server, capture_path)

        parse_shaders(replay_controller, args.spirv_cross, args.spirv_dis, args.required_pass_mask,
                      capture_path, shaders)

        remote_server.CloseCapture(replay_controller)

        replay_controler = None

    # DO YOUR ANALYSIS (USE shaders) AND GENERATE A REPORT (USE report_path)?


if __name__ == '__main__':
    main()
