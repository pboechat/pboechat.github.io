import os
import tempfile

from renderdoc import *

from collections import defaultdict

# Counter present in the Rdoc Meta fork profile mode
RENDERPASS_GPU_DURATION_COUNTER = 15


def get_gpu_counter_str(gpu_counter):
    # TODO
    return str(gpu_counter)


def get_counter_unit_str(counter_unit):
    # TODO:
    return str(counter_unit)


def get_texture_type_str(texture_type):
    if texture_type == TextureType.Unknown:
        return "Unknown"
    elif texture_type == TextureType.Buffer:
        return "Buffer"
    elif texture_type == TextureType.Texture1D:
        return "Texture1D"
    elif texture_type == TextureType.Texture1DArray:
        return "Texture1DArray"
    elif texture_type == TextureType.Texture2D:
        return "Texture2D"
    elif texture_type == TextureType.TextureRect:
        return "TextureRect"
    elif texture_type == TextureType.Texture2DArray:
        return "Texture2DArray"
    elif texture_type == TextureType.Texture2DMS:
        return "Texture2DMS"
    elif texture_type == TextureType.Texture2DMSArray:
        return "Texture2DMSArray"
    elif texture_type == TextureType.Texture3D:
        return "Texture3D"
    elif texture_type == TextureType.TextureCube:
        return "TextureCube"
    elif texture_type == TextureType.TextureCubeArray:
        return "TextureCubeArray"
    else:
        return None


def get_var_type_str(var_type):
    if var_type == VarType.Float:
        return "Float"
    elif var_type == VarType.Double:
        return "Double"
    elif var_type == VarType.Half:
        return "Half"
    elif var_type == VarType.SInt:
        return "SInt"
    elif var_type == VarType.UInt:
        return "UInt"
    elif var_type == VarType.SShort:
        return "SShort"
    elif var_type == VarType.UShort:
        return "UShort"
    elif var_type == VarType.SLong:
        return "SLong"
    elif var_type == VarType.ULong:
        return "ULong"
    elif var_type == VarType.SByte:
        return "SByte"
    elif var_type == VarType.UByte:
        return "UByte"
    elif var_type == VarType.Bool:
        return "Bool"
    elif var_type == VarType.Enum:
        return "Enum"
    elif var_type == VarType.Struct:
        return "Struct"
    elif var_type == VarType.GPUPointer:
        return "GPUPointer"
    elif var_type == VarType.ConstantBlock:
        return "ConstantBlock"
    elif var_type == VarType.ReadOnlyResource:
        return "ReadOnlyResource"
    elif var_type == VarType.ReadWriteResource:
        return "ReadWriteResource"
    elif var_type == VarType.Sampler:
        return "Sampler"
    elif var_type == VarType.Unknown:
        return "Unknown"
    else:
        return None


class Count:
    def __init__(self, init_value=0):
        self._value = init_value

    @property
    def value(self):
        return self._value

    def inc(self):
        self._value += 1


def traverse_action(controller, visitor, action, depth=0, count=Count()):
    # DEBUG:
    # print('%s%d: %s' % ('\t' * depth, action.eventId, action.GetName(controller.GetStructuredFile()))

    visitor(action, depth, count.value)

    count.inc()

    for action in action.children:
        traverse_action(controller, visitor, action, depth + 1, count)


def traverse_actions(controller, visitor):
    for action in controller.GetRootActions():
        traverse_action(controller, visitor, action)


def create_remote_server_connection():
    protocols = GetSupportedDeviceProtocols()

    if 'adb' not in protocols:
        raise RuntimeError('cannot use adb protocol')

    protocol = GetDeviceProtocolController('adb')

    devices = protocol.GetDevices()

    if len(devices) == 0:
        raise RuntimeError(f"No adb devices connected")

    # Choose the first device
    dev = devices[0]
    name = protocol.GetFriendlyName(dev)

    print(f"Running test on {dev} - named {name}")

    url = protocol.GetProtocolName() + "://" + dev

    result, remote_server = CreateRemoteServerConnection(url)
    if result != ResultCode.Succeeded:
        # If there's just no I/O, most likely the server is not running. If we have
        # a protocol, we can try to start the remote server
        print(f"Couldn't connect to remote server, got error {str(result)}. Trying to start it")

        result = protocol.StartRemoteServer(url)

        if result != ResultCode.Succeeded:
            raise RuntimeError(f"Couldn't launch remote server, got error {str(result)}")

        # Try to connect again!
        result, remote_server = CreateRemoteServerConnection(url)

        if result != ResultCode.Succeeded:
            raise RuntimeError("Couldn't connect to remove server")

    return remote_server


def open_remote_capture(remote_server, capture_path, optimisation_level=ReplayOptimisationLevel.Balanced):
    print('Copying capture', end='')
    remote_capture_path = remote_server.CopyCaptureToRemote(capture_path, lambda x: print('.', end='', flush=True))
    print()

    print(f'Remote capture path: {remote_capture_path}')

    print('Opening capture', end='')

    replay_options = ReplayOptions()
    replay_options.optimisation = optimisation_level

    result, replay_controller = remote_server.OpenCapture(remote_server.NoPreference,
                                                          remote_capture_path,
                                                          ReplayOptions(),
                                                          lambda x: print('.', end='', flush=True))
    print()

    if result != ResultCode.Succeeded:
        raise RuntimeError(f"Couldn't initialise replay, got error {str(result)}")

    print('Capture opened!')

    return replay_controller


def get_jpg_data(controller, resource_id, mip=0, slice_index=0):
    tex_save = TextureSave()
    tex_save.resourceId = resource_id

    with tempfile.NamedTemporaryFile() as tmp_file:
        filepath = tmp_file.name

    tex_save.mip = mip
    tex_save.slice.sliceIndex = slice_index

    tex_save.alpha = AlphaMapping.Discard
    tex_save.destType = FileType.JPG

    controller.SaveTexture(tex_save, filepath)

    data = open(filepath, 'rb').read()

    os.remove(filepath)

    return data


def sample_counter(replay_controller, counter, num_samples, **kwargs):
    assert (num_samples > 0)

    counters = replay_controller.EnumerateCounters()

    if counter not in counters:
        raise RuntimeError(f"Implementation doesn't support {get_gpu_counter_str(counter)} counter")

    counter_desc = replay_controller.DescribeCounter(counter)

    expected_unit = kwargs.get('expected_unit', None)
    if expected_unit is not None:
        if counter_desc.unit & expected_unit == 0:
            raise RuntimeError(f"{get_gpu_counter_str(counter)} unit doesn't match "
                               f"expected unit {get_counter_unit_str(expected_unit)}")

    value_transform = kwargs.get('value_transform', None)

    def get_counter_value(counter_result):
        if counter_desc.resultType == CompType.Float \
                or counter_desc.resultType == CompType.UNorm \
                or counter_desc.resultType == CompType.SNorm \
                or counter_desc.resultType == CompType.UScaled \
                or counter_desc.resultType == CompType.SScaled \
                or counter_desc.resultType == CompType.Depth \
                or counter_desc.resultType == CompType.UNormSRGB:
            value = counter_result.value.f if counter_desc.resultByteWidth == 4 else counter_result.value.d
        elif counter_desc.resultType == CompType.UInt \
                or counter_desc.resultType == CompType.SInt:
            value = counter_result.value.u32 if counter_desc.resultByteWidth == 4 else counter_result.value.u64
        if value_transform is not None:
            value = value_transform(value)
        return value

    counter_samples = defaultdict(list)
    for i in range(0, num_samples):
        counter_results = replay_controller.FetchCounters([counter])
        for counter_result in counter_results:
            counter_samples[counter_result.eventId].append(get_counter_value(counter_result))

    return counter_samples
