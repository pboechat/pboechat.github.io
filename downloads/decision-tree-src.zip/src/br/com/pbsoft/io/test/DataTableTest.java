/*    */ package br.com.pbsoft.io.test;
/*    */ 
/*    */ import br.com.pbsoft.io.DataTable;
/*    */ import br.com.pbsoft.io.DataTable.Register;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.util.List;
/*    */ import junit.framework.TestCase;
/*    */ 
/*    */ public class DataTableTest extends TestCase
/*    */ {
/* 13 */   static String[] headers = { "Age", "Education", "Income", "Marital Status", "Purchase?" };
/*    */   private DataTable<String> dataTable;
/*    */ 
/*    */   private void loadDataTable()
/*    */     throws IOException
/*    */   {
/* 18 */     BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("data/sample.dt")));
/*    */     try {
/* 20 */       this.dataTable = DataTable.load(reader, '\n', ';');
/*    */     } catch (IOException e) {
/* 22 */       throw e;
/*    */     } finally {
/* 24 */       reader.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void testFilter() {
/*    */     try {
/* 30 */       loadDataTable();
/* 31 */       this.dataTable.filter("Age", "< 18");
/* 32 */       if (this.dataTable.getRegisters().size() != 3)
/* 33 */         failNotEquals("Filter returned more than 3 registers with age < 18.", Integer.valueOf(3), Integer.valueOf(this.dataTable.getRegisters().size()));
/*    */     } catch (IOException e) {
/* 35 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void testLoad()
/*    */   {
/*    */     try
/*    */     {
/* 43 */       loadDataTable();
/* 44 */       int i = 0;
/* 45 */       for (String header : this.dataTable.getHeader().getColumns()) {
/* 46 */         String expectedHeader = headers[(i++)];
/* 47 */         if (!header.equals(expectedHeader))
/* 48 */           failNotEquals("Invalid header: " + header + ".", expectedHeader, header);
/*    */       }
/*    */     } catch (IOException e) {
/* 51 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-datatable.jar
 * Qualified Name:     br.com.pbsoft.io.test.DataTableTest
 * JD-Core Version:    0.6.2
 */