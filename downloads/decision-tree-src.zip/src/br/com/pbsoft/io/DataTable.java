/*     */ package br.com.pbsoft.io;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DataTable<T>
/*     */ {
/*     */   private Register<T> header;
/*     */   private List<Register<T>> registers;
/*     */ 
/*     */   private DataTable()
/*     */   {
/*  44 */     this.registers = new ArrayList();
/*     */   }
/*     */ 
/*     */   public DataTable(DataTable<T> dataTable) {
/*  48 */     this();
/*  49 */     this.header = dataTable.header;
/*  50 */     this.registers.addAll(dataTable.registers);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  54 */     return this.registers.isEmpty();
/*     */   }
/*     */ 
/*     */   public DataTable<T> filter(T arg0, T arg1) {
/*  58 */     int colPos = this.header.getColumns().indexOf(arg0);
/*  59 */     List toRemove = new ArrayList();
/*     */ 
/*  61 */     for (Register register : this.registers) {
/*  62 */       if (!register.getColumns().get(colPos).equals(arg1)) toRemove.add(register);
/*     */     }
/*     */ 
/*  65 */     this.registers.removeAll(toRemove);
/*     */ 
/*  67 */     return this;
/*     */   }
/*     */ 
/*     */   public static DataTable<String> load(BufferedReader reader, char registerDelimiter, char columnDelimiter) throws IOException {
/*  71 */     DataTable dataTable = new DataTable();
/*  72 */     int registerCount = 0;
/*  73 */     Register register = new Register();
/*  74 */     List columns = new ArrayList();
/*  75 */     StringBuffer buffer = new StringBuffer();
/*  76 */     boolean ignoreCarriageReturns = registerDelimiter != '\r';
/*  77 */     boolean ignoreTabs = columnDelimiter != '\t';
/*     */     char c;
/*  80 */     while ((c = (char)reader.read()) != 65535)
/*     */     {
/*     */       char c;
/*  81 */       if (((!ignoreCarriageReturns) || (c != '\r')) && ((!ignoreTabs) || (c != '\t')))
/*     */       {
/*  84 */         if (c == registerDelimiter) {
/*  85 */           if (buffer.length() > 0) {
/*  86 */             columns.add(buffer.toString());
/*  87 */             buffer = new StringBuffer();
/*     */           }
/*  89 */           register.setIndex(registerCount);
/*  90 */           register.setColumns(columns);
/*  91 */           if (registerCount++ == 0)
/*  92 */             dataTable.setHeader(register);
/*     */           else
/*  94 */             dataTable.getRegisters().add(register);
/*  95 */           register = new Register();
/*  96 */           columns = new ArrayList();
/*  97 */         } else if (c == columnDelimiter) {
/*  98 */           columns.add(buffer.toString());
/*  99 */           buffer = new StringBuffer();
/*     */         } else {
/* 101 */           buffer.append(c);
/*     */         }
/*     */       }
/*     */     }
/* 104 */     return dataTable;
/*     */   }
/*     */ 
/*     */   public Register<T> getHeader() {
/* 108 */     return this.header;
/*     */   }
/*     */ 
/*     */   public void setHeader(Register<T> header) {
/* 112 */     this.header = header;
/*     */   }
/*     */ 
/*     */   public List<Register<T>> getRegisters() {
/* 116 */     return this.registers;
/*     */   }
/*     */ 
/*     */   public void setRegisters(List<Register<T>> registers) {
/* 120 */     this.registers = registers;
/*     */   }
/*     */ 
/*     */   public static class Register<T>
/*     */   {
/*     */     private int index;
/*     */     private List<T> columns;
/*     */ 
/*     */     public int getIndex()
/*     */     {
/*  17 */       return this.index;
/*     */     }
/*     */ 
/*     */     public void setIndex(int index) {
/*  21 */       this.index = index;
/*     */     }
/*     */ 
/*     */     public List<T> getColumns()
/*     */     {
/*  26 */       return this.columns;
/*     */     }
/*     */ 
/*     */     public void setColumns(List<T> columns)
/*     */     {
/*  31 */       this.columns = columns;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-datatable.jar
 * Qualified Name:     br.com.pbsoft.io.DataTable
 * JD-Core Version:    0.6.2
 */