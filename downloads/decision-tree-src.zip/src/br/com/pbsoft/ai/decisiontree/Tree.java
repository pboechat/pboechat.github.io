/*    */ package br.com.pbsoft.ai.decisiontree;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ public abstract class Tree<T>
/*    */   implements Comparable<Tree<T>>
/*    */ {
/*    */   private T value;
/*    */   private Set<Tree<T>> children;
/*    */ 
/*    */   public Tree<T> getFirstChild()
/*    */   {
/* 14 */     return (Tree)this.children.iterator().next();
/*    */   }
/*    */ 
/*    */   public Set<Tree<T>> getChildren() {
/* 18 */     return this.children;
/*    */   }
/*    */ 
/*    */   public Tree<T> getChildAt(int index) {
/* 22 */     return (Tree)new ArrayList(this.children).get(index);
/*    */   }
/*    */ 
/*    */   public int getIndex(Tree<T> child) {
/* 26 */     return new ArrayList(this.children).indexOf(child);
/*    */   }
/*    */ 
/*    */   public T getValue() {
/* 30 */     return this.value;
/*    */   }
/*    */ 
/*    */   public boolean hasChildren() {
/* 34 */     return this.children != null;
/*    */   }
/*    */ 
/*    */   Tree(T value) {
/* 38 */     this.value = value;
/* 39 */     this.children = null;
/*    */   }
/*    */ 
/*    */   Tree(T value, Set<Tree<T>> children) {
/* 43 */     this(value);
/* 44 */     this.children = children;
/*    */   }
/*    */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-ai.jar
 * Qualified Name:     br.com.pbsoft.ai.decisiontree.Tree
 * JD-Core Version:    0.6.2
 */