/*    */ package br.com.pbsoft.ai.decisiontree.test;
/*    */ 
/*    */ import br.com.pbsoft.ai.decisiontree.EntropicBestAttributeStrategy;
/*    */ import br.com.pbsoft.io.DataTable;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import junit.framework.TestCase;
/*    */ import org.junit.Test;
/*    */ 
/*    */ public class EntropicBestAttributeStrategyTest extends TestCase
/*    */ {
/*    */   private DataTable<String> trainingDataSet;
/*    */ 
/*    */   private void loadDataTable(String dataSampleFileName)
/*    */     throws IOException
/*    */   {
/* 22 */     BufferedReader reader = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(dataSampleFileName)));
/*    */     try {
/* 24 */       this.trainingDataSet = DataTable.load(reader, '\n', ';');
/*    */     } catch (IOException e) {
/* 26 */       throw e;
/*    */     } finally {
/* 28 */       reader.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   @Test
/*    */   public void testGetBest1() {
/* 34 */     List attributes = new ArrayList((Collection)Arrays.asList(new String[] { "Age", "Education", "Income", "Marital Status" }));
/*    */ 
/* 36 */     EntropicBestAttributeStrategy s = new EntropicBestAttributeStrategy(4, "will buy");
/*    */     try
/*    */     {
/* 40 */       loadDataTable("/data/sample1.dt");
/*    */ 
/* 42 */       String bestAttribute = s.getBest(this.trainingDataSet, attributes);
/* 43 */       if (!bestAttribute.equals("Age")) failNotEquals("Best attribute not valid.", "Age", bestAttribute);
/* 44 */       attributes.remove(bestAttribute);
/* 45 */       DataTable filteredDataSet = new DataTable(this.trainingDataSet).filter("Age", "< 18");
/* 46 */       bestAttribute = s.getBest(filteredDataSet, attributes);
/* 47 */       if (!bestAttribute.equals("Income")) failNotEquals("Best attribute not valid.", "Income", bestAttribute);
/* 48 */       filteredDataSet = new DataTable(this.trainingDataSet).filter("Age", "36-55");
/* 49 */       bestAttribute = s.getBest(filteredDataSet, attributes);
/* 50 */       if (!bestAttribute.equals("Marital Status")) failNotEquals("Best attribute not valid.", "Marital Status", bestAttribute); 
/*    */     }
/* 52 */     catch (IOException e) { e.printStackTrace(); }
/*    */   }
/*    */ 
/*    */   @Test
/*    */   public void testGetBest2()
/*    */   {
/* 58 */     List attributes = new ArrayList((Collection)Arrays.asList(new String[] { "Alternative", "Bar", "Weekend", "Hungry", "Clients", "Price", "Raining", "Reservation", "Type", "Estimate" }));
/*    */ 
/* 60 */     EntropicBestAttributeStrategy s = new EntropicBestAttributeStrategy(10, "yes");
/*    */     try
/*    */     {
/* 64 */       loadDataTable("/data/sample2.dt");
/*    */ 
/* 66 */       String bestAttribute = s.getBest(this.trainingDataSet, attributes);
/* 67 */       if (!bestAttribute.equals("Clients")) failNotEquals("Best attribute not valid.", "Clients", bestAttribute);
/*    */ 
/* 69 */       attributes.remove("Clients");
/* 70 */       DataTable filteredDataSet = new DataTable(this.trainingDataSet).filter("Clients", "full");
/* 71 */       bestAttribute = s.getBest(filteredDataSet, attributes);
/* 72 */       if (!bestAttribute.equals("Hungry")) failNotEquals("Best attribute not valid.", "Hungry", bestAttribute);
/*    */ 
/* 74 */       attributes.remove("Hungry");
/* 75 */       filteredDataSet.filter("Hungry", "yes");
/* 76 */       bestAttribute = s.getBest(filteredDataSet, attributes);
/* 77 */       if (!bestAttribute.equals("Type")) failNotEquals("Best attribute not valid.", "Type", bestAttribute);
/*    */ 
/* 79 */       attributes.remove("Type");
/* 80 */       filteredDataSet.filter("Type", "thai");
/* 81 */       bestAttribute = s.getBest(filteredDataSet, attributes);
/* 82 */       if (!bestAttribute.equals("Weekend")) failNotEquals("Best attribute not valid.", "Weekend", bestAttribute); 
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 85 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-ai.jar
 * Qualified Name:     br.com.pbsoft.ai.decisiontree.test.EntropicBestAttributeStrategyTest
 * JD-Core Version:    0.6.2
 */