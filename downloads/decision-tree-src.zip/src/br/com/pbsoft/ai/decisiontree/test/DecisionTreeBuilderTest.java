/*    */ package br.com.pbsoft.ai.decisiontree.test;
/*    */ 
/*    */ import br.com.pbsoft.ai.decisiontree.DecisionTree;
/*    */ import br.com.pbsoft.ai.decisiontree.DecisionTreeBuilder;
/*    */ import br.com.pbsoft.ai.decisiontree.EntropicBestAttributeStrategy;
/*    */ import br.com.pbsoft.ai.decisiontree.Pair;
/*    */ import br.com.pbsoft.ai.decisiontree.Tree;
/*    */ import br.com.pbsoft.io.DataTable;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import junit.framework.TestCase;
/*    */ import org.junit.Test;
/*    */ 
/*    */ public class DecisionTreeBuilderTest extends TestCase
/*    */ {
/*    */   private DataTable<String> trainingDataSet;
/*    */ 
/*    */   private void loadDataTable(String dataSampleFileName)
/*    */     throws IOException
/*    */   {
/* 21 */     BufferedReader reader = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(dataSampleFileName)));
/*    */     try {
/* 23 */       this.trainingDataSet = DataTable.load(reader, '\n', ';');
/*    */     } catch (IOException e) {
/* 25 */       throw e;
/*    */     } finally {
/* 27 */       reader.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   @Test
/*    */   public void testBuild1()
/*    */   {
/*    */     try
/*    */     {
/* 36 */       loadDataTable("/data/sample1.dt");
/*    */ 
/* 38 */       DecisionTree dt = new DecisionTreeBuilder(this.trainingDataSet, 4, "will buy", "won't buy", new EntropicBestAttributeStrategy(4, "will buy")).build();
/*    */ 
/* 40 */       if (!((String)((Pair)dt.getValue()).getKey()).equals("Age"))
/* 41 */         failNotEquals("First attribute node in decision tree not valid.", "Age", ((Pair)dt.getValue()).getKey());
/* 42 */       else if (!((String)((Pair)dt.getChildByValue("< 18").getFirstChild().getValue()).getKey()).equals("Income"))
/* 43 */         failNotEquals("Second attribute node in decision tree not valid.", "Income", ((Pair)dt.getValue()).getKey());
/* 44 */       else if (!((String)((Pair)dt.getChildByValue("36-55").getFirstChild().getValue()).getKey()).equals("Marital Status"))
/* 45 */         failNotEquals("Third attribute node in decision tree not valid.", "Marital Status", ((Pair)dt.getValue()).getKey());
/*    */     }
/*    */     catch (IOException e) {
/* 48 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   @Test
/*    */   public void testBuild2()
/*    */   {
/*    */     try
/*    */     {
/* 57 */       loadDataTable("/data/sample2.dt");
/*    */ 
/* 59 */       DecisionTree dt = new DecisionTreeBuilder(this.trainingDataSet, 10, "yes", "no", new EntropicBestAttributeStrategy(10, "yes")).build();
/*    */ 
/* 61 */       if (!((String)((Pair)dt.getValue()).getKey()).equals("Clients"))
/* 62 */         failNotEquals("First attribute node in decision tree not valid.", "Clients", ((Pair)dt.getValue()).getKey());
/* 63 */       else if (!((String)((Pair)(dt = (DecisionTree)dt.getChildByValue("full").getFirstChild()).getValue()).getKey()).equals("Hungry"))
/* 64 */         failNotEquals("Second attribute node in decision tree not valid.", "Hungry", ((Pair)dt.getValue()).getKey());
/* 65 */       else if (!((String)((Pair)(dt = (DecisionTree)dt.getChildByValue("yes").getFirstChild()).getValue()).getKey()).equals("Type"))
/* 66 */         failNotEquals("Third attribute node in decision tree not valid.", "Type", ((Pair)dt.getValue()).getKey());
/* 67 */       else if (!((String)((Pair)(dt = (DecisionTree)dt.getChildByValue("thai").getFirstChild()).getValue()).getKey()).equals("Weekend"))
/* 68 */         failNotEquals("Third attribute node in decision tree not valid.", "Weekend", ((Pair)dt.getValue()).getKey());
/*    */     }
/*    */     catch (IOException e) {
/* 71 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-ai.jar
 * Qualified Name:     br.com.pbsoft.ai.decisiontree.test.DecisionTreeBuilderTest
 * JD-Core Version:    0.6.2
 */