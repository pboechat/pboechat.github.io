package br.com.pbsoft.ai.decisiontree.gui.swing;

import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import br.com.pbsoft.ai.decisiontree.DecisionTree;

public class DecisionTreeModel implements TreeModel {

	private DecisionTree root;
	
	public DecisionTreeModel(DecisionTree root) {
		this.root = root;
	}

	@Override
	public void addTreeModelListener(TreeModelListener arg0) {
		
	}

	@Override
	public Object getChild(Object arg0, int arg1) {
		return ((DecisionTree) arg0).getChildAt(arg1);
	}

	@Override
	public int getChildCount(Object arg0) {
		return ((DecisionTree) arg0).getChildren().size();
	}

	@Override
	public int getIndexOfChild(Object arg0, Object arg1) {
		return ((DecisionTree) arg0).getIndex((DecisionTree) arg1);
	}

	@Override
	public Object getRoot() {
		return root;
	}

	@Override
	public boolean isLeaf(Object arg0) {
		return !((DecisionTree) arg0).hasChildren();
	}

	@Override
	public void removeTreeModelListener(TreeModelListener arg0) {
		
	}

	@Override
	public void valueForPathChanged(TreePath arg0, Object arg1) {
		
	}

}
