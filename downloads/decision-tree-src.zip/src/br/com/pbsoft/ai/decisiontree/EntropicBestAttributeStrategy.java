/*     */ package br.com.pbsoft.ai.decisiontree;
/*     */ 
/*     */ import br.com.pbsoft.io.DataTable;
/*     */ import br.com.pbsoft.io.DataTable.Register;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class EntropicBestAttributeStrategy
/*     */   implements BestAttributeStrategy
/*     */ {
/*     */   private int targetAttributeIndex;
/*     */   private String positiveTargetValue;
/*     */ 
/*     */   public EntropicBestAttributeStrategy(int targetAttributeIndex, String positiveTargetValue)
/*     */   {
/*  17 */     this.targetAttributeIndex = targetAttributeIndex;
/*  18 */     this.positiveTargetValue = positiveTargetValue;
/*     */   }
/*     */ 
/*     */   private Map<String, Integer[]> getValueFrequencyMap(DataTable<String> dataTable, String attribute) {
/*  22 */     Map frequencyMap = new TreeMap();
/*     */ 
/*  24 */     int attrPos = dataTable.getHeader().getColumns().indexOf(attribute);
/*     */ 
/*  26 */     for (DataTable.Register register : dataTable.getRegisters()) {
/*  27 */       String value = (String)register.getColumns().get(attrPos);
/*  28 */       String targetValue = (String)register.getColumns().get(this.targetAttributeIndex);
/*  29 */       Integer[] frequency = (Integer[])frequencyMap.get(value);
/*  30 */       if (frequency == null) {
/*  31 */         frequency = new Integer[] { Integer.valueOf(0), targetValue.equals(this.positiveTargetValue) ? new Integer[] { Integer.valueOf(1), Integer.valueOf(0) } : Integer.valueOf(1) };
/*  32 */       } else if (targetValue.equals(this.positiveTargetValue))
/*     */       {
/*     */         int tmp174_173 = 0;
/*     */         Integer[] tmp174_171 = frequency; tmp174_171[tmp174_173] = Integer.valueOf(tmp174_171[tmp174_173].intValue() + 1);
/*     */       }
/*     */       else
/*     */       {
/*     */         int tmp191_190 = 1;
/*     */         Integer[] tmp191_188 = frequency; tmp191_188[tmp191_190] = Integer.valueOf(tmp191_188[tmp191_190].intValue() + 1);
/*     */       }
/*  37 */       frequencyMap.put(value, frequency);
/*     */     }
/*     */ 
/*  40 */     return frequencyMap;
/*     */   }
/*     */ 
/*     */   private double totalInformation(DataTable<String> examples) {
/*  44 */     int p = 0; int n = 0;
/*     */ 
/*  47 */     for (DataTable.Register register : examples.getRegisters()) {
/*  48 */       String targetValue = (String)register.getColumns().get(this.targetAttributeIndex);
/*  49 */       if (targetValue.equals(this.positiveTargetValue))
/*  50 */         p++;
/*     */       else {
/*  52 */         n++;
/*     */       }
/*     */     }
/*     */ 
/*  56 */     double prb = p / (p + n);
/*  57 */     return Math.abs(prb * (Math.log(prb) / Math.log(2.0D)) + (prb = 1.0D - prb) * (Math.log(prb) / Math.log(2.0D)));
/*     */   }
/*     */ 
/*     */   private double reminder(DataTable<String> examples, String attribute) {
/*  61 */     double LOG_E_2 = Math.log(2.0D);
/*  62 */     Map frequencyMap = getValueFrequencyMap(examples, attribute);
/*  63 */     int p = 0; int n = 0;
/*  64 */     double r = 0.0D;
/*     */ 
/*  66 */     for (String value : frequencyMap.keySet()) {
/*  67 */       p += ((Integer[])frequencyMap.get(value))[0].intValue();
/*  68 */       n += ((Integer[])frequencyMap.get(value))[1].intValue();
/*     */     }
/*     */ 
/*  71 */     for (String value : frequencyMap.keySet()) {
/*  72 */       int pi = ((Integer[])frequencyMap.get(value))[0].intValue();
/*  73 */       int ni = ((Integer[])frequencyMap.get(value))[1].intValue();
/*     */ 
/*  75 */       double prb1 = (pi + ni) / (p + n);
/*     */ 
/*  79 */       double prb2 = pi / (pi + ni);
/*     */ 
/*  81 */       double i = prb2 > 0.0D ? prb2 * Math.abs(Math.log(prb2) / LOG_E_2) : 0.0D;
/*     */ 
/*  83 */       prb2 = ni / (pi + ni);
/*     */ 
/*  85 */       i += (prb2 > 0.0D ? prb2 * Math.abs(Math.log(prb2) / LOG_E_2) : 0.0D);
/*     */ 
/*  88 */       r += prb1 * i;
/*     */     }
/*     */ 
/*  91 */     return r;
/*     */   }
/*     */ 
/*     */   private double gain(DataTable<String> examples, String attribute) {
/*  95 */     double TOTAL_INFORMATION = totalInformation(examples);
/*  96 */     return TOTAL_INFORMATION - reminder(examples, attribute);
/*     */   }
/*     */ 
/*     */   public String getBest(DataTable<String> examples, List<String> attributes)
/*     */   {
/* 101 */     String bestAttribute = null;
/* 102 */     double g1 = 0.0D;
/*     */ 
/* 104 */     for (String attribute : attributes)
/*     */     {
/*     */       double g2;
/* 105 */       if (g1 < (g2 = gain(examples, attribute))) {
/* 106 */         bestAttribute = attribute;
/* 107 */         g1 = g2;
/*     */       }
/*     */     }
/*     */ 
/* 111 */     return bestAttribute;
/*     */   }
/*     */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-ai.jar
 * Qualified Name:     br.com.pbsoft.ai.decisiontree.EntropicBestAttributeStrategy
 * JD-Core Version:    0.6.2
 */