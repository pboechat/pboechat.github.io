package br.com.pbsoft.ai.decisiontree.gui.swing;

import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.TreeCellRenderer;

import br.com.pbsoft.ai.decisiontree.DecisionTree;

public class DecisionTreeCellRenderer implements TreeCellRenderer {

	@Override
	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
		try {
			DecisionTree dt = ((DecisionTree) value);
			return new JLabel((dt.getValue().getValue() != null) ? dt.getValue().getValue() : dt.getValue().getKey());
		} catch (ClassCastException e) {
			return new JLabel();
		}
	}

}
