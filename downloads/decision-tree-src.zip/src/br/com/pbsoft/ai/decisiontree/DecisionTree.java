/*    */ package br.com.pbsoft.ai.decisiontree;
/*    */ 
/*    */ import java.util.Set;
/*    */ 
/*    */ public class DecisionTree extends Tree<Pair<String, String>>
/*    */ {
/*    */   public DecisionTree(Pair<String, String> value, Set<Tree<Pair<String, String>>> children)
/*    */   {
/*  8 */     super(value, children);
/*    */   }
/*    */ 
/*    */   public DecisionTree(Pair<String, String> value) {
/* 12 */     super(value);
/*    */   }
/*    */ 
/*    */   public Tree<Pair<String, String>> getChildByValue(String value) {
/* 16 */     for (Tree child : getChildren()) {
/* 17 */       if (((String)((Pair)child.getValue()).getValue()).equals(value)) return child;
/*    */     }
/* 19 */     return null;
/*    */   }
/*    */ 
/*    */   public int compareTo(Tree<Pair<String, String>> o)
/*    */   {
/* 24 */     return ((Pair)getValue()).compareTo((Pair)o.getValue());
/*    */   }
/*    */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-ai.jar
 * Qualified Name:     br.com.pbsoft.ai.decisiontree.DecisionTree
 * JD-Core Version:    0.6.2
 */