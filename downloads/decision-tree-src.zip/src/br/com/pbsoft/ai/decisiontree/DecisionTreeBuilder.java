/*     */ package br.com.pbsoft.ai.decisiontree;
/*     */ 
/*     */ import br.com.pbsoft.io.DataTable;
/*     */ import br.com.pbsoft.io.DataTable.Register;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ public class DecisionTreeBuilder
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private DataTable<String> trainingDataSet;
/*     */   private int targetAttributeIndex;
/*     */   private String positiveTargetValue;
/*     */   private String negativeTargetValue;
/*     */   protected BestAttributeStrategy strategy;
/*     */ 
/*     */   public DecisionTreeBuilder(DataTable<String> trainingDataSet, int targetAttributeIndex, String positiveTargetValue, String negativeTargetValue, BestAttributeStrategy strategy)
/*     */   {
/*  56 */     this.trainingDataSet = trainingDataSet;
/*  57 */     this.targetAttributeIndex = targetAttributeIndex;
/*  58 */     this.positiveTargetValue = positiveTargetValue;
/*  59 */     this.negativeTargetValue = negativeTargetValue;
/*  60 */     this.strategy = strategy;
/*     */   }
/*     */ 
/*     */   private StringList getTargetValueForEachExample(DataTable<String> examples) {
/*  64 */     StringList values = new StringList();
/*     */ 
/*  66 */     for (DataTable.Register register : examples.getRegisters()) {
/*  67 */       values.add((String)register.getColumns().get(this.targetAttributeIndex));
/*     */     }
/*     */ 
/*  70 */     return values;
/*     */   }
/*     */ 
/*     */   private String getMostFrequentTargetValue(DataTable<String> examples) {
/*  74 */     StringList values = getTargetValueForEachExample(examples);
/*  75 */     int occurrency = 0;
/*  76 */     String mostFrequentValue = null;
/*     */ 
/*  78 */     for (String value : values) {
/*  79 */       if ((occurrency == 0) || (occurrency < values.occurrency(value))) {
/*  80 */         mostFrequentValue = value;
/*     */       }
/*     */     }
/*     */ 
/*  84 */     return mostFrequentValue;
/*     */   }
/*     */ 
/*     */   private Set<String> getAllPossibleValues(DataTable<String> example, String attribute) {
/*  88 */     TreeSet valueSet = new TreeSet();
/*  89 */     int attrPos = example.getHeader().getColumns().indexOf(attribute);
/*     */ 
/*  91 */     for (DataTable.Register register : example.getRegisters()) {
/*  92 */       valueSet.add((String)register.getColumns().get(attrPos));
/*     */     }
/*     */ 
/*  95 */     return valueSet;
/*     */   }
/*     */ 
/*     */   private int targetValuesMask(DataTable<String> examples) {
/*  99 */     StringList values = getTargetValueForEachExample(examples);
/* 100 */     int positiveTargetValueOccurrency = values.occurrency(this.positiveTargetValue);
/* 101 */     return positiveTargetValueOccurrency == 0 ? 15 : positiveTargetValueOccurrency == values.size() ? 240 : 0;
/*     */   }
/*     */ 
/*     */   public DecisionTree build() {
/* 105 */     List attributes = this.trainingDataSet.getHeader().getColumns();
/* 106 */     attributes.remove(this.targetAttributeIndex);
/* 107 */     return build(this.trainingDataSet, attributes, this.strategy.getBest(this.trainingDataSet, attributes));
/*     */   }
/*     */ 
/*     */   private DecisionTree build(DataTable<String> examples, List<String> attributes, String targetAttribute)
/*     */   {
/*     */     int targetValuesMask;
/* 117 */     if ((((targetValuesMask = targetValuesMask(examples)) & 0xF0) != 0) || ((targetValuesMask & 0xF) != 0)) {
/* 118 */       return new DecisionTree(new Pair(null, (targetValuesMask & 0xF0) != 0 ? this.positiveTargetValue : this.negativeTargetValue));
/*     */     }
/*     */ 
/* 121 */     if ((examples.isEmpty()) || (attributes.isEmpty())) {
/* 122 */       return new DecisionTree(new Pair(null, getMostFrequentTargetValue(examples)));
/*     */     }
/* 124 */     Set children = new TreeSet();
/*     */ 
/* 126 */     attributes = new StringList(attributes).remove(targetAttribute);
/*     */ 
/* 128 */     for (String value : getAllPossibleValues(examples, targetAttribute)) {
/* 129 */       DataTable examplesSubset = new DataTable(examples).filter(targetAttribute, value);
/*     */ 
/* 131 */       String nextAttribute = this.strategy.getBest(examplesSubset, attributes);
/*     */ 
/* 133 */       if (examplesSubset.isEmpty())
/* 134 */         children.add(new DecisionTree(new Pair(null, getMostFrequentTargetValue(examples))));
/*     */       else {
/* 136 */         children.add(new DecisionTree(
/* 137 */           new Pair(targetAttribute, value), 
/* 138 */           new TreeSet((Collection)Arrays.asList(new DecisionTree[] { build(examplesSubset, attributes, nextAttribute) }))));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 144 */     return new DecisionTree(new Pair(targetAttribute, null), children);
/*     */   }
/*     */ 
/*     */   private static class StringList extends ArrayList<String>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public StringList()
/*     */     {
/*     */     }
/*     */ 
/*     */     public StringList(List<String> listToCopy)
/*     */     {
/*  26 */       super();
/*     */     }
/*     */ 
/*     */     public int occurrency(String value) {
/*  30 */       Iterator i = iterator();
/*  31 */       int c = 0;
/*  32 */       while (i.hasNext()) {
/*  33 */         if (value.equals(i.next())) c++;
/*     */       }
/*  35 */       return c;
/*     */     }
/*     */ 
/*     */     public StringList remove(String value) {
/*  39 */       super.remove(value);
/*  40 */       return this;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-ai.jar
 * Qualified Name:     br.com.pbsoft.ai.decisiontree.DecisionTreeBuilder
 * JD-Core Version:    0.6.2
 */