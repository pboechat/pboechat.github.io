/*    */ package br.com.pbsoft.ai.decisiontree;
/*    */ 
/*    */ public class Pair<K extends Comparable<K>, V extends Comparable<V>>
/*    */   implements Comparable<Pair<K, V>>
/*    */ {
/*    */   private K key;
/*    */   private V value;
/*    */ 
/*    */   public K getKey()
/*    */   {
/*  9 */     return this.key;
/*    */   }
/*    */ 
/*    */   public void setKey(K key) {
/* 13 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public V getValue() {
/* 17 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(V value) {
/* 21 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Pair(K key, V value) {
/* 25 */     this.key = key;
/* 26 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public int compareTo(Pair<K, V> o)
/*    */   {
/* 31 */     if (this.value != null)
/* 32 */       return this.value.compareTo(o.value);
/* 33 */     if (this.key != null) {
/* 34 */       return this.key.compareTo(o.key);
/*    */     }
/* 36 */     return 0;
/*    */   }
/*    */ }

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-ai.jar
 * Qualified Name:     br.com.pbsoft.ai.decisiontree.Pair
 * JD-Core Version:    0.6.2
 */