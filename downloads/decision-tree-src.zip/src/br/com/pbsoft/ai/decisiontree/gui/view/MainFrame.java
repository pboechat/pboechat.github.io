package br.com.pbsoft.ai.decisiontree.gui.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.DefaultMutableTreeNode;

import br.com.pbsoft.ai.decisiontree.DecisionTree;
import br.com.pbsoft.ai.decisiontree.DecisionTreeBuilder;
import br.com.pbsoft.ai.decisiontree.EntropicBestAttributeStrategy;
import br.com.pbsoft.ai.decisiontree.gui.swing.DecisionTreeCellRenderer;
import br.com.pbsoft.ai.decisiontree.gui.swing.DecisionTreeModel;
import br.com.pbsoft.io.DataTable;

public class MainFrame extends JFrame implements ActionListener {

	private static final int DEFAULT_HEIGHT = 450;

	private static final int DEFAULT_WIDTH = 300;

	private static final long serialVersionUID = 1L;
	
	private JTree jTree1;
	
	private JMenuBar jMenuBar1;
	
	private JLabel jLabel1, jLabel2, jLabel3;
	
	private JTextField jTextInput1, jTextInput2, jTextInput3;
	
	private JMenuItem jMenuItem1, jMenuItem2;
	
	private JButton jButton1;
	
	private File selectedDataTableFile;
	
	public MainFrame() throws HeadlessException {
		super("decision-tree-gui");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setResizable(false);
		
		setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
		
		setLayout(new BorderLayout());
		
		jMenuBar1 = new JMenuBar();
		jMenuItem1 = new JMenuItem("Open");
		jMenuItem1.addActionListener(this);
		jMenuBar1.add(jMenuItem1);
		jMenuItem2 = new JMenuItem("Exit");
		jMenuItem2.addActionListener(this);
		jMenuBar1.add(jMenuItem2);
		
		getContentPane().add(jMenuBar1, BorderLayout.NORTH);
		
		JPanel jPanel1 = new JPanel();
		jPanel1.setPreferredSize(new Dimension(300, 100));
		jPanel1.setLayout(new GridLayout(4, 2));
		jLabel1 = new JLabel("Target attribute index:");
		jLabel2 = new JLabel("Positive target value:");
		jLabel3 = new JLabel("Negative target value:");
		jTextInput1 = new JTextField();
		jTextInput2 = new JTextField();
		jTextInput3 = new JTextField();
		jPanel1.add(jLabel1);
		jPanel1.add(jTextInput1);
		jPanel1.add(jLabel2);
		jPanel1.add(jTextInput2);
		jPanel1.add(jLabel3);
		jPanel1.add(jTextInput3);
		jButton1 = new JButton("Parse");
		jButton1.addActionListener(this);
		jPanel1.add(jButton1);
		
		getContentPane().add(jPanel1, BorderLayout.CENTER);
		
		jTree1 = new JTree(new DefaultMutableTreeNode());
		jTree1.setPreferredSize(new Dimension(300, 300));
		jTree1.setCellRenderer(new DecisionTreeCellRenderer());
		getContentPane().add(jTree1, BorderLayout.SOUTH);
		
		pack();
	}
	
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			new MainFrame().setVisible(true);
		} catch (HeadlessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == jMenuItem1) {
			JFileChooser jFileChooser1 = new JFileChooser();
			jFileChooser1.setFileFilter(new FileFilter() {

				@Override
				public String getDescription() {
					return "Data Table File (*.dt)";
				}

				@Override
				public boolean accept(File arg0) {
					return (arg0.isDirectory() || arg0.getName().endsWith(".dt"));
				}
				
			});
			jFileChooser1.showOpenDialog(this);
			selectedDataTableFile = jFileChooser1.getSelectedFile();
		} else if (arg0.getSource() == jMenuItem2) {
			dispose();
		} else if (arg0.getSource() == jButton1) {
			if (selectedDataTableFile != null) {
				try {
					int targetAttributeIndex = Integer.parseInt(jTextInput1.getText());
					String positiveTargetValue = jTextInput2.getText(),
							negativeTargetValue = jTextInput3.getText();
					DataTable<String> trainingDataSet = DataTable.load(new BufferedReader(new InputStreamReader(new FileInputStream(selectedDataTableFile))), '\n', ';');
					DecisionTreeBuilder decisionTreeBuilder =  new DecisionTreeBuilder(trainingDataSet,
		  				    targetAttributeIndex,
		  				    positiveTargetValue,
		  				    negativeTargetValue,
		  				    new EntropicBestAttributeStrategy(targetAttributeIndex, positiveTargetValue));
					DecisionTree decisionTree = decisionTreeBuilder.build();
					jTree1.setModel(new DecisionTreeModel(decisionTree));
					
				} catch (Throwable t) {
					JOptionPane.showMessageDialog(this, "Error parsing file.", "", JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}
	
}
