package br.com.pbsoft.ai.decisiontree;

import br.com.pbsoft.io.DataTable;
import java.util.List;

public abstract interface BestAttributeStrategy
{
  public abstract String getBest(DataTable<String> paramDataTable, List<String> paramList);
}

/* Location:           C:\Users\Pedro\Desktop\decision-tree-gui\lib\commons-ai.jar
 * Qualified Name:     br.com.pbsoft.ai.decisiontree.BestAttributeStrategy
 * JD-Core Version:    0.6.2
 */